from django.shortcuts import render

def index(request):
    return render(request, 'index.html')  # Make sure you have index.html inside todo/templates/
