from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # This means the homepage will show your ToDo list
]
